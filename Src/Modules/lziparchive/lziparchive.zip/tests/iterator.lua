require 'ziparchive'
archive = ziparchive.open('o.zip')
for entry in archive:files("*.h") do print(entry) end
