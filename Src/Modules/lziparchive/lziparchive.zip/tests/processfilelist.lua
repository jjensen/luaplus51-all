require 'ziparchive'

archive = ziparchive.new()

--[[
archive:create('out.zip')
archive:fileinsert("luaw.pdb", "luaw.pdb")
archive:fileinsert("luaw.exe", "luaw.exe")
archive:flush(true)
archive:close()

archive:open('out.zip', false)
archive:pack({ DirectoryAtBeginning = true })
archive:close()

archive:open('out.zip', false)
archive:pack() --{ DirectoryAtBeginning = true })
archive:close()
]]


StatusUpdate_StatusToText = {}
StatusUpdate_StatusToText[ziparchive.UPDATING_ARCHIVE] = "-> "
StatusUpdate_StatusToText[ziparchive.DELETING_ENTRY] = "\tdel: "
StatusUpdate_StatusToText[ziparchive.COPYING_ENTRY_FROM_CACHE] = "\tfrom-cache: "
StatusUpdate_StatusToText[ziparchive.COPYING_ENTRY_TO_CACHE] = "\tto-cache: "
StatusUpdate_StatusToText[ziparchive.UPDATING_ENTRY] = "\tupdate: "
StatusUpdate_StatusToText[ziparchive.DIRECT_COPY_FROM_ANOTHER_ARCHIVE] = "\tdirect-copy: "
StatusUpdate_StatusToText[ziparchive.PACKING_ARCHIVE] = "-*> "
StatusUpdate_StatusToText[ziparchive.PACKING_COPY] = "\tpack-copy: "

fileListOptions =
{
--	FileCache = 'thecache',
	StatusUpdate = function(status, text)
		io.write(StatusUpdate_StatusToText[status] .. text .. '\n')
	end,

--[[	RetrieveChecksum = function(sourcePath)
		local crc, md5 = ziparchive.filecrcmd5(sourcePath)
		print(sourcePath, crc, md5)
		return crc, md5
	end,]]

	RequiresPack = false,
}



FileOrder = {}
FileOrder[#FileOrder + 1] = {
	EntryName = "lziparchive.jam",
	SourcePath = "../lziparchive.jam",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "lziparchive.cpp",
	SourcePath = "../lziparchive.cpp",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "ZipArchive.cpp",
	SourcePath = "../Misc/ZipArchive.cpp",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "lziparchive.cpp",
	SourcePath = "../lziparchive.cpp",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "ZipArchive.h",
	SourcePath = "../Misc/ZipArchive.h",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "License.txt",
	SourcePath = "../License.txt",
}

archive:open('o.zip', 'a', ziparchive.SUPPORT_MD5 | ziparchive.EXTRA_DIRECTORY_AT_BEGINNING)
fileListOptions.RequiresPack = true
print(archive:processfilelist(FileOrder, fileListOptions))
archive:close()




FileOrder = {}
FileOrder[#FileOrder + 1] = {
	EntryName = "License.txt",
	SourcePath = "../License.txt",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "ZipArchive.cpp",
	SourcePath = "o.zip|ZipArchive.cpp",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "lziparchive.jam",
	SourcePath = "../lziparchive.jam",
}
FileOrder[#FileOrder + 1] = {
	EntryName = "lziparchive.cpp",
	SourcePath = "o.zip|lziparchive.cpp",
}

archive:open('out.zip', 'a', ziparchive.SUPPORT_MD5) -- | ziparchive.EXTRA_DIRECTORY_AT_BEGINNING)
fileListOptions.RequiresPack = false
print(archive:processfilelist(FileOrder, fileListOptions))
archive:close()

archive:open('out.zip', 'a')
archive:pack()
archive:close()

--[[

FileOrder = {}
FileOrder[#FileOrder + 1] = {
	EntryName = "luaw.exe",
	SourcePath = "luaw.exe",
}
--FileOrder[#FileOrder + 1] = {
--	EntryName = "luaw.pdb",
--	SourcePath = "luaw.pdb",
--}

archive:open('out.zip', false)
archive:processfilelist(FileOrder, { DirectoryAtBeginning = true })
archive:close()




archive:open('out.zip', false)
archive:fileinsert("luaw.pdb", "luaw.pdb")
archive:flush(true)
archive:close()


archive:open('out.zip', false)
archive:fileerase("luaw.exe")
archive:pack{ DirectoryAtBeginning = true }
archive:flush(true)
archive:close()
]]
